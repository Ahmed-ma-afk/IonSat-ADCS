# MaximumTorqueEnvelope
Example code for "Maximum Reaction-wheel Array Torque/Momentum Envelopes for General Configurations", Journal of Guidance Control and Dynamics, AIAA
